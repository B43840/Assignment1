﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level1_BallMove : MonoBehaviour {

	// Use this for initialization
	void Start () {
		int rand = Random.Range (0, 2);
		if (rand == 0) {
			this.GetComponent<Rigidbody2D> ().velocity = new Vector2 (-5f, 0f);
		} else if (rand == 1) {
			this.GetComponent<Rigidbody2D> ().velocity = new Vector2 (5f, 0f);
		}
	}

	// Update is called once per frame
	void Update () {
		
		if (this.transform.position.x >= 7f) {
			this.GetComponent<Rigidbody2D> ().position = new Vector2 (0f, 0f);
			this.GetComponent<Rigidbody2D> ().velocity = new Vector2 (5f, 0f);
		}
		if (this.transform.position.x <= -7f) {
			this.GetComponent<Rigidbody2D> ().position = new Vector2 (0f, 0f);
			this.GetComponent<Rigidbody2D> ().velocity = new Vector2 (-5f, 0f);
		}
	}

}
