﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class CountBlueScore : MonoBehaviour {
	public Text Scoreboard;
	public GameObject ball;

	private int BlueScore = 0;
	private int RedScore = 0;

	// Use this for initialization
	void Start () {
		ball = GameObject.Find ("Ball");
	}
	
	// Update is called once per frame
	void Update () {
		if (ball.transform.position.x >= 7f) {
			BlueScore ++;
		}
		if (ball.transform.position.x <= -7f) {
			RedScore ++;
		}
		if (BlueScore >= 3) {
			SceneManager.LoadScene (2);
		}
		if (RedScore >= 3) {
			SceneManager.LoadScene (2);
		}
		Scoreboard.text = BlueScore.ToString () + " - " + RedScore.ToString ();
		print (BlueScore);
	}

}
